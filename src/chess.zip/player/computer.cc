#include "computer.h"

Computer::Computer(string colour, bool isComputer) : Player{colour, isComputer} {} 

Computer::~Computer() {}
